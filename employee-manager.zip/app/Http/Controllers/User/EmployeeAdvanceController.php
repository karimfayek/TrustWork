<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\User;
use App\Models\Advance;
use Inertia\Inertia;
class EmployeeAdvanceController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();

        $advances = $user->advances()->select('amount', 'note', 'given_at')->get();
        $expenses = $user->expenses()->select('amount', 'description', 'spent_at')->get();

        $totalAdvance = $advances->sum('amount');
        $totalExpense = $expenses->sum('amount');
        $remaining = $totalAdvance - $totalExpense;

        return Inertia::render('Employee/Advance', [
            'advances' => $advances,
            'expenses' => $expenses,
            'totalAdvance' => $totalAdvance,
            'totalExpense' => $totalExpense,
            'remaining' => $remaining,
        ]);
    }

    public function storeAdvance(Request $request)
{
    $request->validate([
        'amount' => 'required|numeric|min:1',
        'note' => 'nullable|string|max:255',
    ]);
      // dd($request->all());
    $user = $request->user_id
        ? User::findOrFail($request->user_id) // الإدمن يضيف لشخص معين
        : $request->user(); // الموظف يضيف لنفسه

    $user->advances()->create([
        'amount' => $request->amount,
        'note' => $request->note,
        'given_at' => now(),
    ]);

    return redirect()->back()->with('success', 'تم تسجيل العهدة.');
}

public function deleteAdvance(Request $request)
{
    //dd($request->all());
    $request->validate([
        'id' => 'required|exists:advances,id',
    ]);
      // dd($request->all());
    $advance = Advance::find($request->id);
    $advance->delete();

    return redirect()->back()->with('success', 'تم مسح العهدة.');
}

public function storeExpense(Request $request)
{
    $request->validate([
        'amount' => 'required|numeric|min:1',
        'description' => 'required|string|max:255',
    ]);
    $user = $request->user_id
    ? User::findOrFail($request->user_id) // الإدمن يضيف لشخص معين
    : $request->user(); // الموظف يضيف لنفسه

$user->expenses()->create([
        'amount' => $request->amount,
        'description' => $request->description,
        'spent_at' => now(),
    ]);

    return redirect()->back()->with('success', 'تم تسجيل المصروف.');
}

}
