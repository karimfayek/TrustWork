<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Attendance;
use App\Models\Project;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Services\EmployeePerformanceService;
class AttendanceController extends Controller
{
   
    
    public function checkIn(Request $request, Project $project)
    {
        $user = auth()->user();
    
        // Check if already checked in today
        $existing = Attendance::whereDate('check_in_time', now()->toDateString())
                    ->where('user_id', $user->id)
                    ->where('project_id', $project->id)
                    ->first();
    
        if ($existing) {
            return back()->with('message', 'تم تسجيل حضورك مسبقًا اليوم.');
        }
    
        Attendance::create([
            'user_id' => $user->id,
            'project_id' => $project->id,
            'check_in_time' => now(),
            'location' => $request->input('location', 'غير محدد'),
            'is_late' => now()->hour >= 9, // تعتبر متأخر بعد الساعة 9 صباحًا
        ]);
    
        return back()->with('message', 'تم تسجيل الحضور بنجاح.');
    }
    public function checkOut(Project $project)
{
    $user = auth()->user();

    $attendance = Attendance::where('user_id', $user->id)
        ->where('project_id', $project->id)
        ->whereDate('check_in_time', today())
        ->whereNull('check_out_time')
        ->first();

    if (!$attendance) {
        return back()->withErrors(['message' => 'لم يتم تسجيل الحضور أولاً.']);
    }

    $attendance->update([
        'check_out_time' => now(),
    ]);

    return back()->with('message', 'تم تسجيل الانصراف بنجاح.');
}
public function calculateAttendancePercentage($userId, $month=null)
{
    // تحديد بداية ونهاية الشهر المطلوب
    $month =Carbon::create(null, Carbon::now()->month, 1);
    $startOfMonth = Carbon::parse($month)->startOfMonth();
    $endOfMonth = Carbon::parse($month)->endOfMonth();

    $workingDays = 0;
    for ($date = $startOfMonth->copy(); $date->lte($endOfMonth); $date->addDay()) {
        if ($date->dayOfWeek !== Carbon::FRIDAY)
        { 
            $workingDays++;
        }
    }
    
    if ($workingDays == 0) {
        return 0; 
    }
 //until today
 $today = Carbon::now()->startOfDay();
 $workingDaysUntilltoday = 0;
 $current = $startOfMonth->copy();

 while ($current <= $today) {
     //, Carbon::SATURDAY
     if (!in_array($current->dayOfWeek, [Carbon::FRIDAY])) {
         $workingDaysUntilltoday++;
     }
     $current->addDay();
 }

    // عدد أيام الحضور للموظف خلال الشهر
    $attendanceDays = Attendance::where('user_id', $userId)
        ->whereBetween('check_in_time', [$startOfMonth, $endOfMonth])
        ->count();

    $attendanceUntilToday = Attendance::where('user_id', $userId)
    ->whereDate('check_in_time', '>=', $startOfMonth)
    ->whereDate('check_in_time', '<=', $today)
    ->distinct()
    ->count('check_in_time');

    // عدد أيام الغياب
    $absenceDays = max(0, $workingDaysUntilltoday - $attendanceUntilToday);
    //$absenceDaysInMonth = max(0, $workingDays - $attendanceUntilToday);

    // حساب النسبة
    $attendancePercentage = ($attendanceDays / $workingDays) * 100;
    $lateAttendances = Attendance::where('user_id', $userId)
    ->whereBetween('check_in_time', [$startOfMonth, $endOfMonth])
    ->where('is_late', true)
    ->count();
    //return $attendanceDays;

    $user = User::find($userId);
    $alltasks =  $user->tasks()
    ->whereBetween('tasks.due_date', [$startOfMonth, $endOfMonth])
    ->count();
    $tasksCompleted = $user->tasks()
    ->where('is_completed', 1)
    ->whereBetween('tasks.due_date', [$startOfMonth, $endOfMonth])
    ->count();
    if($alltasks === 0){
        $completedTasksPercentage = 100 ; 
        $tasksCompleted = 0; 
    }else{
        $completedTasksPercentage = ($tasksCompleted / $alltasks) * 100;
    }
   

    $variableSalary = $user->salary->final_salary - $user->salary->base_salary ; // 2000
    $taskFees = ($variableSalary / 100 ) * 65; // 1300
    $lateFees = ($variableSalary / 100 ) * 35; // 700
    $taskScore = ( $taskFees / 100) * $completedTasksPercentage; // 100
    $latePercentage =  ( $lateAttendances / $workingDays) * 100 ; // 3.8
    $lateScore = ( $lateFees / 100) * $latePercentage; // 100
//$assignments = $user->toolassignments->with('toolassignments.tool') ;
$assignments = $user->toolassignments()->with('tool')->get();
$lostThismonth =  $user->toolassignments() ->whereBetween('lost_at', [$startOfMonth, $endOfMonth])->get();
$lostCostThisMonth = 0 ;
foreach($lostThismonth as $lostItem){
    $lostCostThisMonth +=$lostItem->tool->estimated_value * $lostItem->quantity;
}
//advances deduction


    return [
        'attendance_percentage' => round($attendancePercentage, 2),
        'total_days' => $workingDays,
        'late_days' => $lateAttendances,
        'att_days' => $attendanceDays,
        'alltasks' => $alltasks,
        'tasksCompleted' => $tasksCompleted,
        'completedTasksPercentage' => $completedTasksPercentage,
        'absenceDays'=> $absenceDays,
        'taskScore'=> $taskScore,
        'lateScore' => $lateScore,
        'lateFees' => $lateFees,
        'assignments' => $assignments,
        'lostThismonth'=>$lostThismonth,
        'lostCostThisMonth'=>$lostCostThisMonth
    ];
    //return round($attendancePercentage, 2); // نقربها لرقمين عشريين
}
public function calculateAttendancePercentageUntillToday($userId, $month=null)
{
    

    $service = new EmployeePerformanceService();
    $data = $service->calculate($userId, $month);

    return response()->json($data);
 
    //return round($attendancePercentage, 2); // نقربها لرقمين عشريين
}
public function countLateAttendances($userId, $month)
{
    $month = Carbon::create(null, Carbon::now()->month, 1);
    $startOfMonth = Carbon::parse($month)->startOfMonth();
    $endOfMonth = Carbon::parse($month)->endOfMonth();

    $lateAttendances = Attendance::where('user_id', $userId)
        ->whereBetween('check_in_time', [$startOfMonth, $endOfMonth])
        ->where('is_late', true)
        ->count();

    return $lateAttendances;
}


}

