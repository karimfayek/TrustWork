<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Project;
use App\Models\User;
use App\Models\Task;
use Illuminate\Http\Request;
use Inertia\Inertia;

class ProjectController extends Controller
{
    public function create()
    {
        // جلب جميع الموظفين
        $users = User::where('role', 'employee')->get();
        return Inertia::render('Projects/Create', compact('users'));
    }

    public function edit($id)
    {
        // جلب جميع الموظفين
        $users = User::where('role', 'employee')->get();
        $project = Project::with('tasks' , 'tasks.users', 'users')->find($id);
       
        $userIds = $project->users->pluck('id');
   
        return Inertia::render('Projects/Edit', compact('users', 'project','userIds'));
    }
    
    public function deleteTask($id)
    {
        
       $task = Task::find($id);
       $task->delete();
       return ['success' => true];
    }
    public function show($id)
    {
        $project = Project::find($id);
        $tasks = $project->tasks()->with('users')->get();
        $users = $project->users;
    
        return Inertia::render('Projects/ProjectDetails', [
            'project' => $project,
            'tasks' => $tasks,
            'users' => $users,
        ]);
    }
    public function store(Request $request)
    {
        //dd($request->tasks);
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'start_date' => 'required|date',
            'end_date' => 'nullable|date',
            'user_ids' => 'required|array',
            'tasks' => 'required|array',
            'tasks.*.title' => 'required|string|max:255',
            'tasks.*.description' => 'nullable|string',
            'tasks.*.start_date' => 'required|date',
            'tasks.*.end_date' => 'required|date',
            'tasks.*.quantity' => 'required|integer',
            'tasks.*.unit' => 'required|string',
        ]);

        // إنشاء المشروع
        $project = Project::create([
            'name' => $request->name,
            'description' => $request->description,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
            'created_by' => auth()->id(),
        ]);

        // ربط الموظفين بالمشروع
        $project->users()->attach($request->user_ids);

        // إضافة المهام للمشروع
        foreach ($request->tasks as $taskData) {
           $task = Task::create([
                'title' => $taskData['title'],
                'description' => $taskData['description'],
                'start_date' => $taskData['start_date'],
                'end_date' => $taskData['end_date'],
                'quantity' => $taskData['quantity'],
                'unit' => $taskData['unit'],
                'project_id' => $project->id,
            ]);          
            $user = User::findOrFail($taskData['user']);
            $user->tasks()->attach($task->id, ['project_id' =>  $project->id]);
        }
       

        return redirect()->route('admin.dashboard')->with('status', 'تم إضافة المشروع بنجاح!');
    }
    public function update(Request $request)
    {
      
       $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'start_date' => 'required|date',
            'end_date' => 'nullable|date',
            'user_ids' => 'nullable|array',
            'tasks' => 'nullable|array',
            'tasks.*.title' => 'nullable|string|max:255',
            'tasks.*.description' => 'nullable|string',
            'tasks.*.start_date' => 'nullable|date',
            'tasks.*.end_date' => 'nullable|date',
            'tasks.*.quantity' => 'nullable|integer',
            'tasks.*.unit' => 'nullable|string',
            'tasksnew.*.title' => 'nullable|string|max:255',
            'tasksnew.*.description' => 'nullable|string',
            'tasksnew.*.start_date' => 'nullable|date',
            'tasksnew.*.end_date' => 'nullable|date',
            'tasksnew.*.quantity' => 'nullable|integer',
            'tasksnew.*.unit' => 'nullable|string',
        ]);
     //dd($request->all());
        $project = Project::find($request->projectId);
        $project->update([
            'name' => $request->name,
            'description' => $request->description,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
            'created_by' => auth()->id(),
        ]);
       // dd($request->tasksnew);
        $project->users()->sync($request->user_ids);
        // Update the task
        foreach ($request->tasksnew as $taskData) {
            
            $task = Task::create([
                 'title' => $taskData['title'],
                 'description' => $taskData['description'],
                 'start_date' => $taskData['start_date'],
                 'end_date' => $taskData['end_date'],
                 'quantity' => $taskData['quantity'],
                 'unit' => $taskData['unit'],
                 'project_id' => $project->id,
             ]);          
             $user = User::findOrFail($taskData['user']);
             $user->tasks()->attach($task->id, ['project_id' =>  $project->id]);
         }
         foreach ($request->tasks as $taskData) {
           
            $task = Task::find($taskData['id']);
            $task->update([
                 'title' => $taskData['title'],
                 'description' => $taskData['description'],
                 'start_date' => $taskData['start_date'],
                 'end_date' => $taskData['end_date'],
                 'quantity' => $taskData['quantity'],
                 'unit' => $taskData['unit'],
                 'project_id' => $project->id,
             ]);          
             $user = User::findOrFail($taskData['user']);

            $task->users()->sync([
                $taskData['user'] => ['project_id' => $project->id]
            ]);
            
         }
        
    
        // Sync the user (attach if not already)
      
    
        return back()->with('status', 'تم تحديث المهمة بنجاح!'); // "Task updated successfully"
    }

    public function assignTasks($projectId)
    {
        $project = Project::with('tasks', 'users')->findOrFail($projectId);
        $tasks = Task::with('users')->get(); // جلب جميع المهام المتاحة
        $users = User::where('role' , 'employee')->get(); // جلب جميع الموظفين
    
        // إرسال البيانات إلى React عبر Inertia
        return Inertia::render('Projects/AssignTasks', [
            'project' => $project,
            'tasks' => $tasks,
            'users' => $users,
        ]);
    }
    
    public function saveTasks(Request $request, $projectId)
    {
        $project = Project::findOrFail($projectId);
    
        // تخصيص المهام للموظفين
      
        if ($request->has('employee_tasks')) {
            foreach ($request->employee_tasks as $taskId => $userId) {
                $task = Task::findOrFail($taskId);
                $user = User::findOrFail($userId);
                
                // Sync the selected user (replaces any existing assignments)
                $task->users()->sync([$userId => ['project_id' => $projectId]]);
            }
        }
    
        return redirect()->route('admin.dashboard')->with('success', 'Tasks assigned successfully');
    }
}
