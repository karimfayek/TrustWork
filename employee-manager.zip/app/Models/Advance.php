<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Advance extends Model
{
    protected $fillable = [
        'amount', 'user_id' , 'given_at','note','location','is_late'
    ];
}
