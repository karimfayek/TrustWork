<?php
namespace App\Services;

use App\Models\Attendance;
use App\Models\User;
use App\Models\Visit;
use App\Models\Reward;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class EmployeePerformanceService
{
    public function calculate($userId, $month = null)
    {
        $monthData = $this->getMonthBoundaries($month);
        $user = User::with(['tasks.progress', 'salary', 'toolassignments.tool'])->findOrFail($userId);

        $workingDays = $this->countWorkingDays($monthData['start'], $monthData['end']);
        $workingDaysUntilToday = $this->countWorkingDaysUntilToday($monthData['start'], $monthData['end'], $month);
        $attendance = $this->getAttendanceData($userId, $monthData['start'], $monthData['today']);
        $taskData = $this->getTaskData($user, $monthData['start'], $monthData['end']);
        $penaltyScores = $this->calculateScores($user, $taskData['completedTasksPercentage'], $workingDays, $attendance['late_days'] , $attendance['present_days']);
        $tools = $this->getToolAssignments($user, $monthData['start'], $monthData['end']);
        $financials = $this->getFinancials($user, $monthData['start'], $monthData['end']);
        $transportFees = $this->calculateTransportFees($attendance['visits']);
        $rewards = $this->getRewards($userId, $monthData['start'], $monthData['end']);

        return [
            'attendance_percentage' => round($attendance['percentage'], 2),
            'deductions' => $financials['deductions'],
            'rewards' => $rewards,
            'visits' => $attendance['visits'],
            'totalAdvance' => $financials['advances'],
            'totalExpense' => $financials['expenses'],
            'remaining' => $financials['remaining'],
            'transportaionFees' => $transportFees,
            'total_days' => $workingDays,
            'late_days' => $attendance['late_days'],
            'att_days' => $attendance['present_days'],
            'alltasks' => $taskData['totalTasks'],
            'tasksCompleted' => $taskData['completedCount'],
            'completedTasksPercentage' => $taskData['completedTasksPercentage'],
            'absenceDays' => max(0, $workingDaysUntilToday - $attendance['present_days']),
            'taskScore' => $penaltyScores['taskScore'],
            'lateScore' => $penaltyScores['lateScore'],
            'lateFees' => $penaltyScores['lateFees'],
            'assignments' => $tools['all'],
            'lostThismonth' => $tools['lost'],
            'lostCostThisMonth' => $tools['lostCost'],
        ];
    }

    private function getMonthBoundaries($month)
    {
        $month = $month == null || $month == 'null' ? Carbon::now()->month : $month;
        $carbonMonth = Carbon::create(null, $month, 1);
        return [
            'start' => $carbonMonth->copy()->startOfMonth(),
            'end' => $carbonMonth->copy()->endOfMonth(),
            'today' => ($month == Carbon::now()->month) ? Carbon::now()->startOfDay() : $carbonMonth->copy()->endOfMonth(),
        ];
    }

    private function countWorkingDays($start, $end)
    {
        $days = 0;
        for ($date = $start->copy(); $date->lte($end); $date->addDay()) {
            if ($date->dayOfWeek !== Carbon::FRIDAY) {
                $days++;
            }
        }
        return $days;
    }

    private function countWorkingDaysUntilToday($start, $end, $month)
    {
        $today = ($month == null || $month == 'null') ? Carbon::now()->startOfDay() : $end;
        $count = 0;
        for ($date = $start->copy(); $date->lte($today); $date->addDay()) {
            if (!in_array($date->dayOfWeek, [Carbon::FRIDAY])) {
                $count++;
            }
        }
        return $count;
    }

    private function getAttendanceData($userId, $start, $today)
    {
        $attendanceDays = Attendance::where('user_id', $userId)
            ->whereDate('check_in_time', '>=', $start)
            ->whereDate('check_in_time', '<=', $today)
            ->distinct()
            ->count('check_in_time');

        $visitDays = Visit::where('user_id', $userId)
            ->whereDate('check_in', '>=', $start)
            ->whereDate('check_in', '<=', $today)
            ->distinct(DB::raw('DATE(check_in)'))
            ->count();

        $lateAttendances = Attendance::where('user_id', $userId)
            ->whereBetween('check_in_time', [$start, $today])
            ->where('is_late', true)
            ->count();

        $lateVisits = Visit::select(DB::raw('DATE(check_in) as visit_date'), DB::raw('MIN(check_in) as first_check_in'))
            ->where('user_id', $userId)
            ->whereDate('check_in', '>=', $start)
            ->whereDate('check_in', '<=', $today)
            ->groupBy(DB::raw('DATE(check_in)'))
            ->havingRaw('TIME(first_check_in) > "09:00:00"')
            ->count();

        return [
            'present_days' => $attendanceDays + $visitDays,
            'late_days' => $lateAttendances + $lateVisits,
            'percentage' => ($attendanceDays + $visitDays) / max(1, $this->countWorkingDays($start, $today)) * 100,
            'visits' => Visit::where('user_id', $userId)
                ->whereBetween('check_in', [$start, $today])
                ->get()
        ];
    }

    private function getTaskData($user, $start, $end)
    {
        $tasks = $user->tasks()->whereBetween('tasks.end_date', [$start, $end])->with('progress')->get();
        $totalRequired = $tasks->sum('quantity');
        $totalDone = $tasks->flatMap->progress->sum('quantity_done');
        $completedTasksPercentage = $totalRequired > 0 ? ($totalDone / $totalRequired) * 100 : 100;
        $completedCount = $tasks->filter(fn($task) => $task->progress->sum('quantity_done') >= $task->quantity)->count();

        return [
            'totalTasks' => $tasks->count(),
            'completedTasksPercentage' => round($completedTasksPercentage, 2),
            'completedCount' => $completedCount,
        ];
    }

    private function calculateScores($user, $completedTasksPercentage, $workingDays, $lateDays , $attDayes)
    {
      
        if($attDayes > 0 ){
            $variable = $user->salary->final_salary - $user->salary->base_salary;
            $score =  ($variable * $completedTasksPercentage) / 100 ;
        }else{
            $score = 0 ;
        }
        
        $lateFees = $user->salary->base_salary * .03;

        return [
            'taskScore' =>$score ,
            'lateScore' =>  $lateFees * $lateDays,
            'lateFees' => $lateFees ,
        ];
    }

    private function getToolAssignments($user, $start, $end)
    {
        $lost = $user->toolassignments()->whereBetween('lost_at', [$start, $end])->get();
        $cost = $lost->sum(fn($item) => $item->tool->estimated_value * $item->quantity);

        return [
            'all' => $user->toolassignments()->with('tool')->get(),
            'lost' => $lost,
            'lostCost' => $cost,
        ];
    }

    private function getFinancials($user, $start, $end)
    {
        $advances = $user->advances->whereBetween('given_at', [$start, $end])->sum('amount');
        $expenses = $user->expenses->whereBetween('given_at', [$start, $end])->sum('amount');
        $deductions = $user->deductions->sum('amount');

        return [
            'advances' => $advances,
            'expenses' => $expenses,
            'deductions' => $deductions,
            'remaining' => $advances - $expenses
        ];
    }

    private function calculateTransportFees($visits)
    {
        return $visits->sum(fn($visit) => $visit->customer->transport_fees ?? 0);
    }

    private function getRewards($userId, $start, $end)
    {
        return Reward::where('user_id', $userId)
            ->whereBetween('reward_date', [$start, $end])
            ->sum('amount');
    }
}
