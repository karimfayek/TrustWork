import React, { useState, useEffect } from 'react';
import { Head, router, useForm, usePage } from '@inertiajs/react';
import InputLabel from '@/Components/InputLabel';
import TextInput from '@/Components/TextInput';
import PrimaryButton from '@/Components/PrimaryButton';
import InputError from '@/Components/InputError';

export default function EditUser({ user }) {
    const { advances, expenses, totalAdvance, totalExpense, remaining, deductions } = usePage().props;

    const [attData, setAttData] = useState({})
    const [month, setMonth] = useState(null)
    const absenceScore = Number(attData?.absenceDays) * Number(Number(user.salary?.base_salary) * .10)
    const deserved = Number(Number(user.salary?.base_salary) + Number(attData?.taskScore) + Number(attData?.rewards) - absenceScore - Number(attData?.lateScore) + Number(attData?.transportaionFees) - Number(attData.lostCostThisMonth) - Number(attData.deductions) - Number(attData.remaining)).toFixed(2)

    const currentDate = new Date();
    const currentMonth = currentDate.getMonth() + 1;
    console.log('user', user)
    useEffect(() => {
        fetch(`/calc-emp-att/${user.id}/${month}`)
            .then((res) => {
                return res.json();
            })
            .then((data) => {
                console.log('attdata', data);
                setAttData(data);
            });
    }, [month]);
    const { data, setData, post, processing, errors } = useForm({
        name: user?.name || '',
        final_salary: user?.salary?.final_salary || '',
        base_salary: user?.salary?.base_salary || '',
        email: user?.email || '',
        password: '',
    });
    const handleDeleteAdvance = (id) => {
        //e.preventDefault();
        console.log(id)

        router.post(route('admin.advance.delete'), { id }, {
            preserveScroll: true,
        });
    }
    const handleSubmit = (e) => {
        e.preventDefault();
        post(route('admin.user.update', user.id));
    };

    const {
        data: advanceData,
        setData: setAdvanceData,
        post: postAdvance,
        processing: processingAdvance,
        reset: resetAdvance,
        errors: advanceErrors,
    } = useForm({
        amount: '',
        note: '',
        user_id: user?.id,
    });
    const {
        data: expenseData,
        setData: setExpenseData,
        post: postExpense,
        processing: processingExpense,
        reset: resetExpense,
        errors: expenseErrors,
    } = useForm({
        amount: '',
        description: '',
        user_id: user?.id,
    });
    const {
        data: deductionData,
        setData: setDeductionData,
        post: postDeduction,
        processing: processingDeduction,
        reset: resetDeduction,
        errors: deductionErrors,
    } = useForm({
        amount: '',
        note: '',
        type: '',
        user_id: user?.id,
    });



    return (
        <>
            <Head title="تعديل موظف " />

            <div className=" px-6 py-8 bg-white rounded shadow">
                <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">تعديل موظف </h1>

                <form onSubmit={handleSubmit} className="space-y-6">
                    {/* اسم الموظف */}
                    <div>
                        <InputLabel htmlFor="name" value="اسم الموظف" />
                        <TextInput
                            id="name"
                            type="text"
                            value={data.name}
                            className="mt-1 block w-full"
                            onChange={(e) => setData('name', e.target.value)}
                        />
                        <InputError message={errors.name} className="mt-2" />
                    </div>
                    <div>
                        <InputLabel htmlFor="email" value="  الايميل" />
                        <TextInput
                            id="email"
                            type="text"
                            value={data.email}
                            className="mt-1 block w-full"
                            onChange={(e) => setData('email', e.target.value)}
                        />
                        <InputError message={errors.email} className="mt-2" />
                    </div>
                    <div>
                        <InputLabel htmlFor="password" value="  الباسورد" />
                        <TextInput
                            id="password"
                            type="text"
                            value={data.password}
                            className="mt-1 block w-full"
                            onChange={(e) => setData('password', e.target.value)}
                        />
                        <InputError message={errors.password} className="mt-2" />
                    </div>

                    <div>
                        <InputLabel htmlFor="base_salary" value=" الراتب الاساسى" />
                        <TextInput
                            id="base_salary"
                            type="text"
                            value={data.base_salary}
                            className="mt-1 block w-full"
                            onChange={(e) => setData('base_salary', e.target.value)}
                        />
                        <InputError message={errors.base_salary} className="mt-2" />
                    </div>
                    <div>
                        <InputLabel htmlFor="final_salary" value=" الراتب النهائى" />
                        <TextInput
                            id="final_salary"
                            type="text"
                            value={data.final_salary}
                            className="mt-1 block w-full"
                            onChange={(e) => setData('final_salary', e.target.value)}
                        />
                        <InputError message={errors.final_salary} className="mt-2" />
                    </div>






                    {/* زر الإرسال */}
                    <div>
                        <PrimaryButton className="w-full justify-center" disabled={processing}>
                            تعديل الموظف
                        </PrimaryButton>
                    </div>
                </form>
                <div className="p-6">
                    <div className="bg-gray-100 mb-12 p-5 shadow-sm">
                        <div>
                            <select className='mb-4 w-48' name="month" id="month" value={month} onChange={(e) => setMonth(e.target.value)}>
                                <option value="null">الى اليوم الحالى</option>
                                <option value="1">يناير </option>
                                <option value="2">فبراير </option>
                                <option value="3">مارس </option>
                                <option value="4">ابريل </option>
                                <option value="5">مايو </option>
                                <option value="6">يونيو </option>
                                <option value="7">يوليو </option>
                                <option value="8">اغسطس </option>
                                <option value="9">سبتمبر </option>
                                <option value="10">اكتوبر </option>
                                <option value="11">نوفمبر </option>
                                <option value="12">ديسمير </option>
                            </select>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">

                            <div className="bg-white p-4 shadow sm:rounded-lg sm:p-8">

                                <h2 className='text-lg font-medium text-gray-900'>
                                    استحقاقات
                                </h2>
                                <hr />
                                <div>
                                    <b>
                                        الاساسي
                                    </b>
                                    <p className='text-green-800'>{(Number(user.salary?.base_salary))}</p>
                                </div>
                                <div>
                                    <b>
                                        مستحق لانجاز المهام
                                    </b>
                                    <p className='text-green-800'> {Number(attData?.taskScore).toFixed(2)}</p>
                                </div>

                                <div>

                                    <b>
                                        الانتقالات
                                    </b>
                                    <p className='text-green-800'> {Number(attData?.transportaionFees).toFixed(2)}</p>
                                </div>
                                <div>

                                    <b>
                                        المكافئات
                                    </b>
                                    <p className='text-green-800'> {Number(attData?.rewards).toFixed(2)}</p>
                                </div>
                            </div>

                            <div className="bg-white p-4 shadow sm:rounded-lg sm:p-8">
                                <h2 className='text-lg font-medium text-gray-900'>
                                    استقطاعات
                                </h2>
                                <hr />
                                <div>
                                    <b>
                                        استقطاعات اساسيه من الراتب
                                    </b>
                                    <p className='text-red-800'>  {Number(attData?.deductions).toFixed(2)}</p>
                                </div>
                                <b>
                                    التاخيرات
                                </b>
                                <p className='text-red-800'>  <span>{Number(attData.lateScore).toFixed(2)} </span></p>
                                <div>
                                    <b>
                                        غياب
                                    </b>
                                    <p className='text-red-800'> <span> {absenceScore}</span></p>
                                </div>
                                <div>
                                    <b>
                                        مفقودات
                                    </b>
                                    <p className='text-red-800'> <span> {attData.lostCostThisMonth}</span></p>
                                </div>

                                <div>
                                    <b>
                                        عهد - مصروفات
                                    </b>
                                    <p className='text-red-800'> {attData?.remaining}</p>
                                </div>

                            </div>
                            <div className='bg-white  shadow sm:rounded-lg sm:p-8 border mt-4 p-2.5 text-center'>
                                <b className='border p-1.5'>
                                    المرتب المستحق
                                </b>
                                <p dir="ltr" className={`font-bold mt-3 text-2xl ${deserved < 1 ? 'text-red-500' : 'text-green-500'}`}>

                                    <br />
                                    {deserved}</p>
                            </div>
                            <div className="bg-white p-4 shadow sm:rounded-lg sm:p-8">
                                <h2 className='text-lg font-medium text-gray-900'>
                                    الحضور
                                </h2>
                                <hr />
                                <b>
                                    النسبة المئوية للحضور
                                </b>
                                <p>{attData?.attendance_percentage} %</p>
                                <div>
                                    <b>
                                        عدد ايام العمل فى الشهر
                                    </b>
                                    <p>{attData?.total_days} يوم</p>
                                </div>
                                <div>
                                    <b>
                                        عدد ايام الحضور المتأخر
                                    </b>
                                    <p>{attData?.late_days}</p>
                                </div>

                                <div>
                                    <b>
                                        عدد ايام الحضور خلال الشهر
                                    </b>
                                    <p>{attData?.att_days}</p>
                                </div>
                                <div>
                                    <b>
                                        عدد ايام الغياب خلال الشهر
                                    </b>
                                    <p>{attData?.absenceDays}</p>
                                </div>



                            </div>
                            <div className="bg-white p-4 shadow sm:rounded-lg sm:p-8">
                                <h2 className='text-lg font-medium text-gray-900'>
                                    المهام
                                </h2>
                                <hr />
                                <b>
                                    اجمالى المهام المسندة خلال الشهر
                                </b>
                                <p>{attData?.alltasks}</p>
                                <div>
                                    <b>
                                        المهام المكتمله
                                    </b>
                                    <p>{attData?.tasksCompleted}</p>
                                </div>
                                <div>
                                    <b>
                                        النسبه المئوية لاكمال المهام
                                    </b>
                                    <p>{attData?.completedTasksPercentage} %</p>
                                </div>

                            </div>
                            <div className="bg-white p-4 shadow sm:rounded-lg sm:p-8">
                                <h2 className='text-lg font-medium text-gray-900'>
                                    الادوات
                                </h2>
                                <hr />
                                <b>
                                    ادوات معه:
                                </b>

                                <ul className='inline-flex flex-wrap'>
                                    {attData.assignments && attData.assignments.map((assign) => (
                                        <>
                                            {assign.status === 'assigned' &&
                                                <li className='bg-[#b7ffb7] p-1.5 m-2'>{assign.tool?.name} * {assign.quantity}</li>
                                            }
                                        </>

                                    ))}
                                </ul>
                                <div>
                                    <b>
                                        ادوات مفقودة:
                                    </b>
                                    {attData.lostThismonth?.length < 1 &&
                                        <p className='bg-[#FF2D20]/10 p-1.5 m-2' > لا يوجد</p>
                                    }
                                    <ul className='inline-flex flex-wrap'>
                                        {attData.lostThismonth && attData.lostThismonth.map((t) => (


                                            <li className='bg-[#FF2D20]/10 p-1.5 m-2'>{t.tool?.name} * {t.quantity} *{t.tool.estimated_value} ج </li>



                                        ))}
                                    </ul>

                                </div>
                                <div>
                                    <b>
                                        قيمه الادوات المفقودة
                                    </b>
                                    <p>
                                        {attData.lostCostThisMonth} ج</p>
                                </div>

                            </div>
                        </div>
                    </div>
                    <h1 className="text-2xl font-bold mb-4">العهدة المالية</h1>

                    <div className="mb-6">
                        <p><strong>إجمالي العهدة:</strong> {totalAdvance} ج</p>
                        <p><strong>إجمالي المصروفات:</strong> {totalExpense} ج</p>
                        <p><strong>المتبقي:</strong> {remaining} ج</p>
                    </div>

                    <div className="md:grid grid-cols-3 gap-6">
                        <div>
                            <h2 className="text-lg font-semibold mb-2">العهد المُستلمة</h2>

                            <ul className="bg-white p-4 rounded shadow">
                                {advances.map((a, index) => (
                                    <li key={index} className="border-b py-2">
                                        <div>📅 {a.given_at}</div>
                                        <div>💵 {a.amount} ج</div>
                                        <div>📝 {a.note}</div>
                                        <button onClick={() => handleDeleteAdvance(a.id)} className='bg-red-100 p-1.5 my-3'> مسح</button>
                                    </li>
                                ))}
                            </ul>
                        </div>

                        <div>
                            <h2 className="text-lg font-semibold mb-2 mt-3">المصروفات</h2>
                            <ul className="bg-white p-4 rounded shadow">
                                {expenses.map((e, index) => (
                                    <li key={index} className="border-b py-2">
                                        <div>📅 {e.spent_at}</div>
                                        <div>💸 {e.amount} ج</div>
                                        <div>📝 {e.description}</div>
                                    </li>
                                ))}
                            </ul>
                        </div>
                        <div>
                            <h2 className="text-lg font-semibold mb-2 mt-3">الاستقطاعات</h2>
                            <ul className="bg-white p-4 rounded shadow">
                                {deductions.map((e, index) => (
                                    <li key={index} className="border-b py-2">
                                        <div>📅 {e.deducted_at}</div>
                                        <div>💸 {e.amount} ج</div>
                                        <div>📝 {e.note}</div>
                                        <div>📝 {e.type}</div>
                                    </li>
                                ))}
                            </ul>
                        </div>


                    </div>
                    <div className="mt-10 md:grid grid-cols-3 gap-6">
                        {/* نموذج العهدة */}
                        <div className="bg-white p-4 rounded shadow">
                            <h3 className="font-semibold mb-2">إضافة عهدة جديدة</h3>
                            <form onSubmit={e => {
                                e.preventDefault();
                                postAdvance(route('employee.advance.store'), {
                                    preserveScroll: true,
                                    onSuccess: () => resetAdvance(),
                                });
                            }}>
                                <input
                                    type="number"
                                    placeholder="المبلغ"
                                    value={advanceData.amount}
                                    onChange={e => setAdvanceData('amount', e.target.value)}
                                    className="w-full border p-2 mb-2"
                                />
                                {advanceErrors.amount && <div className="text-red-600">{advanceErrors.amount}</div>}
                                <input
                                    type="text"
                                    placeholder="ملاحظة"
                                    value={advanceData.note}
                                    onChange={e => setAdvanceData('note', e.target.value)}
                                    className="w-full border p-2 mb-2"
                                />
                                {advanceErrors.note && <div className="text-red-600">{advanceErrors.note}</div>}
                                <button type="submit" disabled={processingAdvance} className="bg-blue-500 text-white px-4 py-2 rounded">
                                    حفظ العهدة
                                </button>
                            </form>
                        </div>

                        {/* نموذج المصروف */}
                        <div className="bg-white p-4 rounded shadow">
                            <h3 className="font-semibold mb-2">إضافة مصروف</h3>
                            <form onSubmit={e => {
                                e.preventDefault();
                                postExpense(route('employee.expense.store'), {
                                    preserveScroll: true,
                                    onSuccess: () => resetExpense(),
                                });
                            }}>
                                <input
                                    type="number"
                                    placeholder="المبلغ"
                                    value={expenseData.amount}
                                    onChange={e => setExpenseData('amount', e.target.value)}
                                    className="w-full border p-2 mb-2"
                                />
                                {expenseErrors.note && <div className="text-red-600">{expenseErrors.note}</div>}
                                <input
                                    type="text"
                                    placeholder="الوصف"
                                    value={expenseData.description}
                                    onChange={e => setExpenseData('description', e.target.value)}
                                    className="w-full border p-2 mb-2"
                                />
                                {expenseErrors.description && <div className="text-red-600">{expenseErrors.description}</div>}
                                <button type="submit" disabled={processingExpense} className="bg-green-500 text-white px-4 py-2 rounded">
                                    حفظ المصروف
                                </button>
                            </form>
                        </div>
                        <div className="bg-white p-4 rounded shadow">
                            <h3 className="font-semibold mb-2">إضافة استقطاعات</h3>
                            <form onSubmit={e => {
                                e.preventDefault();
                                postDeduction(route('admin.deduction.store'), {
                                    preserveScroll: true,
                                    onSuccess: () => resetDeduction(),
                                });
                            }}>
                                <input
                                    type="number"
                                    placeholder="المبلغ"
                                    value={deductionData.amount}
                                    onChange={e => setDeductionData('amount', e.target.value)}
                                    className="w-full border p-2 mb-2"
                                />
                                {deductionErrors.amount && <div className="text-red-600">{deductionErrors.amount}</div>}
                                <input
                                    type="text"
                                    placeholder="type"
                                    value={deductionData.type}
                                    onChange={e => setDeductionData('type', e.target.value)}
                                    className="w-full border p-2 mb-2"
                                    required
                                />
                                {deductionErrors.type && <div className="text-red-600">{deductionErrors.type}</div>}
                                <input
                                    type="text"
                                    placeholder="الوصف"
                                    value={deductionData.note}
                                    onChange={e => setDeductionData('note', e.target.value)}
                                    className="w-full border p-2 mb-2"
                                />
                                {deductionErrors.note && <div className="text-red-600">{deductionErrors.note}</div>}
                                <button type="submit" disabled={processingDeduction} className="bg-green-500 text-white px-4 py-2 rounded">
                                    حفظ الاستقطاع
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
