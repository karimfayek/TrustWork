import React from 'react';
import { usePage, useForm } from '@inertiajs/react';

export default function AdvancePage() {
    const { advances, expenses, totalAdvance, totalExpense, remaining } = usePage().props;
    const {
        data: advanceData,
        setData: setAdvanceData,
        post: postAdvance,
        processing: processingAdvance,
        reset: resetAdvance,
        errors: advanceErrors,
    } = useForm({
        amount: '',
        note: '',
    });
    const {
        data: expenseData,
        setData: setExpenseData,
        post: postExpense,
        processing: processingExpense,
        reset: resetExpense,
        errors: expenseErrors,
    } = useForm({
        amount: '',
        description: '',
    });

    return (
        <div className="p-6">
            <h1 className="text-2xl font-bold mb-4">العهدة المالية</h1>

            <div className="mb-6">
                <p><strong>إجمالي العهدة:</strong> {totalAdvance} ج</p>
                <p><strong>إجمالي المصروفات:</strong> {totalExpense} ج</p>
                <p><strong>المتبقي:</strong> {remaining} ج</p>
            </div>

            <div className="grid grid-cols-2 gap-6">
                <div>
                    <h2 className="text-lg font-semibold mb-2">العهد المُستلمة</h2>
                    <ul className="bg-white p-4 rounded shadow">
                        {advances.map((a, index) => (
                            <li key={index} className="border-b py-2">
                                <div>📅 {a.given_at}</div>
                                <div>💵 {a.amount} ج</div>
                                <div>📝 {a.note}</div>
                            </li>
                        ))}
                    </ul>
                </div>

                <div>
                    <h2 className="text-lg font-semibold mb-2">المصروفات</h2>
                    <ul className="bg-white p-4 rounded shadow">
                        {expenses.map((e, index) => (
                            <li key={index} className="border-b py-2">
                                <div>📅 {e.spent_at}</div>
                                <div>💸 {e.amount} ج</div>
                                <div>📝 {e.description}</div>
                            </li>
                        ))}
                    </ul>
                </div>
                <div className="mt-10 grid grid-cols-2 gap-6">
                    {/* نموذج العهدة */}
                    <div className="bg-white p-4 rounded shadow">
                        <h3 className="font-semibold mb-2">إضافة عهدة جديدة</h3>
                        <form onSubmit={e => {
                            e.preventDefault();
                            postAdvance(route('employee.advance.store'), {
                                onSuccess: () => resetAdvance(),
                            });
                        }}>
                            <input
                                type="number"
                                placeholder="المبلغ"
                                value={advanceData.amount}
                                onChange={e => setAdvanceData('amount', e.target.value)}
                                className="w-full border p-2 mb-2"
                            />
                            <input
                                type="text"
                                placeholder="ملاحظة"
                                value={advanceData.note}
                                onChange={e => setAdvanceData('note', e.target.value)}
                                className="w-full border p-2 mb-2"
                            />
                            {advanceErrors.amount && <div className="text-red-600">{advanceErrors.amount}</div>}
                            <button type="submit" disabled={processingAdvance} className="bg-blue-500 text-white px-4 py-2 rounded">
                                حفظ العهدة
                            </button>
                        </form>
                    </div>

                    {/* نموذج المصروف */}
                    <div className="bg-white p-4 rounded shadow">
                        <h3 className="font-semibold mb-2">إضافة مصروف</h3>
                        <form onSubmit={e => {
                            e.preventDefault();
                            postExpense(route('employee.expense.store'), {
                                onSuccess: () => resetExpense(),
                            });
                        }}>
                            <input
                                type="number"
                                placeholder="المبلغ"
                                value={expenseData.amount}
                                onChange={e => setExpenseData('amount', e.target.value)}
                                className="w-full border p-2 mb-2"
                            />
                            <input
                                type="text"
                                placeholder="الوصف"
                                value={expenseData.description}
                                onChange={e => setExpenseData('description', e.target.value)}
                                className="w-full border p-2 mb-2"
                            />
                            {expenseErrors.amount && <div className="text-red-600">{expenseErrors.amount}</div>}
                            <button type="submit" disabled={processingExpense} className="bg-green-500 text-white px-4 py-2 rounded">
                                حفظ المصروف
                            </button>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    );
}
