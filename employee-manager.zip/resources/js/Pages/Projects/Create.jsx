import React, { useState } from 'react';
import { Head, useForm } from '@inertiajs/react';
import InputLabel from '@/Components/InputLabel';
import TextInput from '@/Components/TextInput';
import PrimaryButton from '@/Components/PrimaryButton';
import InputError from '@/Components/InputError';

export default function CreateProject({ users }) {
    const { data, setData, post, processing, errors } = useForm({
        name: '',
        description: '',
        start_date: '',
        end_date: '',
        user_ids: [],
        tasks: [],
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        post(route('admin.projects.store'));
    };

    const handleAddTask = () => {
        setData('tasks', [...data.tasks, { title: '', description: '', start_date: '', user: '', end_date: '', quantity: '', unit: '' }]);
    };

    const handleTaskChange = (index, field, value) => {
        const newTasks = [...data.tasks];
        newTasks[index][field] = value;
        setData('tasks', newTasks);
    };

    const handleEmployeeChange = (e) => {
        const selected = Array.from(e.target.selectedOptions, opt => opt.value);
        setData('user_ids', selected);
    };

    return (
        <>
            <Head title="إضافة مشروع جديد" />

            <div className="max-w-4xl mx-auto px-6 py-8 bg-white rounded shadow">
                <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">إضافة مشروع جديد</h1>

                <form onSubmit={handleSubmit} className="space-y-6">
                    {/* اسم المشروع */}
                    <div>
                        <InputLabel htmlFor="name" value="اسم المشروع" />
                        <TextInput
                            id="name"
                            type="text"
                            value={data.name}
                            className="mt-1 block w-full"
                            onChange={(e) => setData('name', e.target.value)}
                        />
                        <InputError message={errors.name} className="mt-2" />
                    </div>

                    {/* وصف المشروع */}
                    <div>
                        <InputLabel htmlFor="description" value="وصف المشروع" />
                        <TextInput
                            id="description"
                            type="text"
                            value={data.description}
                            className="mt-1 block w-full"
                            onChange={(e) => setData('description', e.target.value)}
                        />
                        <InputError message={errors.description} className="mt-2" />
                    </div>

                    {/* التواريخ */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <InputLabel htmlFor="start_date" value="تاريخ البداية" />
                            <TextInput
                                id="start_date"
                                type="date"
                                value={data.start_date}
                                className="mt-1 block w-full"
                                onChange={(e) => setData('start_date', e.target.value)}
                            />
                            <InputError message={errors.start_date} className="mt-2" />
                        </div>
                        <div>
                            <InputLabel htmlFor="end_date" value="تاريخ النهاية" />
                            <TextInput
                                id="end_date"
                                type="date"
                                value={data.end_date}
                                className="mt-1 block w-full"
                                onChange={(e) => setData('end_date', e.target.value)}
                            />
                            <InputError message={errors.end_date} className="mt-2" />
                        </div>
                    </div>

                    {/* الموظفين */}
                    <div>
                        <InputLabel htmlFor="user_ids" value="فريق العمل " />
                        <select
                            multiple
                            value={data.user_ids}
                            onChange={handleEmployeeChange}
                            className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        >
                            {users.map(user => (
                                <option key={user.id} value={user.id}>
                                    {user.name}
                                </option>
                            ))}
                        </select>
                        <InputError message={errors.user_ids} className="mt-2" />
                    </div>

                    {/* المهام */}
                    <div>
                        <div className="flex justify-between items-center mb-2 position-sticky top-0 sticky p-3 bg-white">
                            <InputLabel value="بنود المشروع" />
                            <button
                                type="button"
                                onClick={handleAddTask}
                                className="text-sm text-blue-600 hover:underline"
                            >
                                + إضافة بند
                            </button>
                        </div>

                        {data.tasks.map((task, index) => (

                            <div key={index} className="p-4 mb-4 bg-gray-50 rounded border space-y-3 grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <InputLabel value="عنوان البند" />
                                    <TextInput
                                        type="text"
                                        value={task.title}
                                        onChange={(e) => handleTaskChange(index, 'title', e.target.value)}
                                        className="mt-1 block w-full"
                                    />
                                    <InputError message={errors.tasks?.[index]?.title} className="mt-1" />
                                </div>

                                <div>
                                    <InputLabel value="وصف البند" />
                                    <TextInput
                                        type="text"
                                        value={task.description}
                                        onChange={(e) => handleTaskChange(index, 'description', e.target.value)}
                                        className="mt-1 block w-full"
                                    />
                                    <InputError message={errors.tasks?.[index]?.description} className="mt-1" />
                                </div>

                                <div>
                                    <InputLabel value="الكمية " />
                                    <TextInput
                                        type="number"
                                        value={task.quantity}
                                        onChange={(e) => handleTaskChange(index, 'quantity', e.target.value)}
                                        className="mt-1 block w-full"
                                    />
                                    <InputError message={errors.tasks?.[index]?.quantity} className="mt-1" />
                                </div>
                                <div>
                                    <InputLabel value=" الوحدة" />
                                    <select

                                        value={task.unit}
                                        onChange={(e) => handleTaskChange(index, 'unit', e.target.value)}

                                        className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                        >
                                        <option >choose Unit</option>

                                            <option  value='متر'>
                                            متر
                                            </option>
                                            <option  value='عدد'>
                                            عدد
                                            </option>

                                        </select>
                                    <InputError message={errors.tasks?.[index]?.unit} className="mt-1" />
                                </div>

                                <div>
                                    <InputLabel value="تاريخ البداية" />
                                    <TextInput
                                        type="date"
                                        value={task.start_date}
                                        onChange={(e) => handleTaskChange(index, 'start_date', e.target.value)}
                                        className="mt-1 block w-full"
                                    />
                                    <InputError message={errors.tasks?.[index]?.start_date} className="mt-1" />
                                </div>
                                <div>
                                    <InputLabel value="تاريخ النهاية" />
                                    <TextInput
                                        type="date"
                                        value={task.end_date}
                                        onChange={(e) => handleTaskChange(index, 'end_date', e.target.value)}
                                        className="mt-1 block w-full"
                                    />
                                    <InputError message={errors.tasks?.[index]?.end_date} className="mt-1" />
                                </div>
                                <div>
                                    <InputLabel htmlFor="user_ids" value=" للموظف" />
                                    <select

                                        value={task.user}
                                        onChange={(e) => handleTaskChange(index, 'user', e.target.value)}

                                        className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                    >
                                        <option >choose employee</option>
                                        {users.map(user => (
                                            <option key={user.id} value={user.id}>
                                                {user.name}
                                            </option>
                                        ))}
                                    </select>
                                    <InputError message={errors.user_ids} className="mt-2" />
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* زر الإرسال */}
                    <div>
                        <PrimaryButton className="w-full justify-center" disabled={processing}>
                            إضافة المشروع
                        </PrimaryButton>
                    </div>
                </form>
            </div>
        </>
    );
}
