

export default function ProjectProgress ({task}) {
    return (
<>
{task.progress.length > 0 && (
    <div className="mt-6">
        <h3 className="text-md font-semibold mb-2 border-b pb-1">سجل الإنجازات</h3>
        <ul className="space-y-2 text-sm">
            {task.progress.map((entry) => (
                <li key={entry.id} className="bg-gray-100 p-2 rounded border">
                    <div className="flex justify-between">
                        <span>
                            <strong>{entry.quantity_done}</strong> {task.unit}
                        </span>
                        <span className="text-gray-500 text-xs">
                            {new Date(entry.created_at).toLocaleDateString('ar-EG', {
                                year: 'numeric',
                                month: 'short',
                                day: 'numeric',
                            })}
                        </span>
                    </div>
                </li>
            ))}
        </ul>
    </div>
)}

</>
    )
}